export default () => ({
  apiHost: '',
  enabled: false,
  token: '',
  projects: [],
  selectedProject: null,
  settingsLoading: false,
  connectSuccessful: false,
  connectError: false,
  listProjectsEndpoint: '',
  operationsSettingsEndpoint: '',
});
