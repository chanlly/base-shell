export default {
  issues: 'issue-recent-searches',
  merge_requests: 'merge-request-recent-searches',
};
