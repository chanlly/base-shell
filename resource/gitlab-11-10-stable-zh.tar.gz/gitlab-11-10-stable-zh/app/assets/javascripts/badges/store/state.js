export default () => ({
  apiEndpointUrl: null,
  badgeInAddForm: null,
  badgeInEditForm: null,
  badgeInModal: null,
  badges: [],
  docsUrl: null,
  renderedBadge: null,
  isEditing: false,
  isLoading: false,
  isRendering: false,
  isSaving: false,
});
