<!-- This issue requests a technical writer review as required for documentation
     content that was merged without one. -->

<!-- NOTE: Please add a DevOps stage label (format `devops:<stage_name>`)
     and assign the technical writer who is
     [listed for that stage](https://about.gitlab.com/handbook/product/categories/#devops-stages). -->


## References

Merged MR that introduced documentation requiring review: 

Related issue(s): 

## Further Details

<!-- Any additional context, questions, or notes for the technical writer. -->


/label ~Documentation ~docs-review
