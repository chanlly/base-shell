## Description of the proposal

<!--
Please describe the proposal and add a link to the source (for example, http://www.betterspecs.org/).
-->

- [ ] Mention the proposal in the next backend weekly call and the #backend channel to encourage contribution
- [ ] Proceed with the proposal once 50% of the maintainers have weighed in, and 80% of the votes are :+1:
- [ ] Once approved, mention it again in the next backend weekly call and the #backend channel


/label ~"development guidelines"
/label ~"Style decision"
/label ~Documentation

/cc @gitlab-org/maintainers/rails-backend
